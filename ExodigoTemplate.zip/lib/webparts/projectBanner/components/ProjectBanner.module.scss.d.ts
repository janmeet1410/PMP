declare const styles: {
    projectBanner: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=ProjectBanner.module.scss.d.ts.map