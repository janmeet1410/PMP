declare const styles: {
    contactCsForm: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=ContactCsForm.module.scss.d.ts.map