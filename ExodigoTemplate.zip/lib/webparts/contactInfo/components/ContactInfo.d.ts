import * as React from 'react';
import { IContactInfoProps } from './IContactInfoProps';
export interface IContactInfoStates {
    ContactData: any;
}
export default class ContactInfo extends React.Component<IContactInfoProps, IContactInfoStates> {
    constructor(props: IContactInfoProps, state: IContactInfoStates);
    componentDidMount: () => Promise<void>;
    private getContactData;
    render(): React.ReactElement<IContactInfoProps>;
}
//# sourceMappingURL=ContactInfo.d.ts.map