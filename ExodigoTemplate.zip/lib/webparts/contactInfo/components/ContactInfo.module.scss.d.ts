declare const styles: {
    contactInfo: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=ContactInfo.module.scss.d.ts.map