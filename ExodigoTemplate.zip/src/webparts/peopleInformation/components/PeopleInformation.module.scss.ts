/* tslint:disable */
require("./PeopleInformation.module.css");
const styles = {
  peopleInformation: 'peopleInformation_2325ad16',
  teams: 'teams_2325ad16',
  welcome: 'welcome_2325ad16',
  welcomeImage: 'welcomeImage_2325ad16',
  links: 'links_2325ad16'
};

export default styles;
/* tslint:enable */