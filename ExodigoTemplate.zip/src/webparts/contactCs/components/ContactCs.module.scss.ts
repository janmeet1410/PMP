/* tslint:disable */
require("./ContactCs.module.css");
const styles = {
  contactCs: 'contactCs_dd300d5a',
  teams: 'teams_dd300d5a',
  welcome: 'welcome_dd300d5a',
  welcomeImage: 'welcomeImage_dd300d5a',
  links: 'links_dd300d5a'
};

export default styles;
/* tslint:enable */