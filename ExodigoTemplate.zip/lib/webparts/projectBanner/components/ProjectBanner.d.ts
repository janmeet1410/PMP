import * as React from 'react';
import { IProjectBannerProps } from './IProjectBannerProps';
export default class ProjectBanner extends React.Component<IProjectBannerProps, {}> {
    render(): React.ReactElement<IProjectBannerProps>;
    componentDidMount(): Promise<void>;
    RestRequest(url: any, params: any): void;
    GetFormDigestValue(): void;
    addimage(url: any): Promise<void>;
}
//# sourceMappingURL=ProjectBanner.d.ts.map