declare const styles: {
    homeBanner: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=HomeBanner.module.scss.d.ts.map