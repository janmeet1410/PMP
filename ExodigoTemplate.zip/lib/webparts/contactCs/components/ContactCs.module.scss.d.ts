declare const styles: {
    contactCs: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=ContactCs.module.scss.d.ts.map