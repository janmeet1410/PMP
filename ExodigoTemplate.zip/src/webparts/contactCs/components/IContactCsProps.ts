export interface IContactCsProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  ContactButtonTitle:any;
  ContactButtonLink:any;
  ContactButtonFontSize:any;
  ContactButtonFontColor:any;
  ContactButtonBackground:any;
  ContactButtonAlignment:any;
  spfxContext: any;

}
