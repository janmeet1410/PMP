import * as React from 'react';
import { IPeopleInformationProps } from './IPeopleInformationProps';
export interface IPeopleInformationStates {
    PeopleData: any;
    ClientContactData: any;
    ExternalContactData: any;
}
export default class PeopleInformation extends React.Component<IPeopleInformationProps, IPeopleInformationStates> {
    constructor(props: IPeopleInformationProps, state: IPeopleInformationStates);
    componentDidMount: () => Promise<void>;
    private getPeopleData;
    private getClientContactData;
    private getExternalContactData;
    render(): React.ReactElement<IPeopleInformationProps>;
}
//# sourceMappingURL=PeopleInformation.d.ts.map