/* tslint:disable */
require("./ContactInfo.module.css");
const styles = {
  contactInfo: 'contactInfo_3203dc40',
  teams: 'teams_3203dc40',
  welcome: 'welcome_3203dc40',
  welcomeImage: 'welcomeImage_3203dc40',
  links: 'links_3203dc40'
};

export default styles;
/* tslint:enable */