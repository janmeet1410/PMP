import * as React from 'react';
import { IHomeBannerProps } from './IHomeBannerProps';
export default class HomeBanner extends React.Component<IHomeBannerProps, {}> {
    render(): React.ReactElement<IHomeBannerProps>;
    componentDidMount(): void;
}
//# sourceMappingURL=HomeBanner.d.ts.map