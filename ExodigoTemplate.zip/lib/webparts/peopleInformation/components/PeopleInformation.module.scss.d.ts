declare const styles: {
    peopleInformation: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=PeopleInformation.module.scss.d.ts.map