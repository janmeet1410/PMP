import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
export interface IProjectBannerWebPartProps {
    description: string;
    title: string;
    SubBannerFilePicker: any;
    ButtonTitle: any;
    ButtonLink: any;
    TitleFontSize: any;
    TitleFontcolor: any;
    TitleFontAlignment: any;
    DescriptionFontSize: any;
    DescriptionFontcolor: any;
    DescriptionFontAlignment: any;
    BackgrounOverlay: any;
    BackButtonBackground: any;
    BackButtonFontSize: any;
    BackButtonFontColor: any;
    ProjectImage: boolean;
    ProjectImageFilePicker: any;
    TitleDescSpacing: any;
}
export default class ProjectBannerWebPart extends BaseClientSideWebPart<IProjectBannerWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    protected onInit(): Promise<void>;
    render(): void;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ProjectBannerWebPart.d.ts.map