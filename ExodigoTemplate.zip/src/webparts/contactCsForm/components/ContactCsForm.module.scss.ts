/* tslint:disable */
require("./ContactCsForm.module.css");
const styles = {
  contactCsForm: 'contactCsForm_3b56077a',
  teams: 'teams_3b56077a',
  welcome: 'welcome_3b56077a',
  welcomeImage: 'welcomeImage_3b56077a',
  links: 'links_3b56077a'
};

export default styles;
/* tslint:enable */