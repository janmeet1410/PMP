import * as React from 'react';
import { IContactCsFormProps } from './IContactCsFormProps';
export interface IContactCsFormStates {
    CSEmails: any;
    FirstName: string;
    LastName: string;
    Email: string;
    PhoneNumber: any;
    CompanyName: string;
    MsgDetail: string;
}
export default class ContactCsForm extends React.Component<IContactCsFormProps, IContactCsFormStates> {
    constructor(props: IContactCsFormProps, state: IContactCsFormStates);
    componentDidMount: () => Promise<void>;
    private getCSEmailData;
    render(): React.ReactElement<IContactCsFormProps>;
    private sendEmail;
}
//# sourceMappingURL=ContactCsForm.d.ts.map