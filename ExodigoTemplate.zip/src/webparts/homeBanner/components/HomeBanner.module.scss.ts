/* tslint:disable */
require("./HomeBanner.module.css");
const styles = {
  homeBanner: 'homeBanner_43fc2e4c',
  teams: 'teams_43fc2e4c',
  welcome: 'welcome_43fc2e4c',
  welcomeImage: 'welcomeImage_43fc2e4c',
  links: 'links_43fc2e4c'
};

export default styles;
/* tslint:enable */