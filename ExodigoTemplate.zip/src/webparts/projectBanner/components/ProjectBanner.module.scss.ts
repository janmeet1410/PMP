/* tslint:disable */
require("./ProjectBanner.module.css");
const styles = {
  projectBanner: 'projectBanner_ea846e02',
  teams: 'teams_ea846e02',
  welcome: 'welcome_ea846e02',
  welcomeImage: 'welcomeImage_ea846e02',
  links: 'links_ea846e02'
};

export default styles;
/* tslint:enable */