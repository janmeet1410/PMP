import * as React from 'react';
import styles from './PeopleInformation.module.scss';
import { IPeopleInformationProps } from './IPeopleInformationProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { sp } from '@pnp/sp/presets/all';
import { HttpClient, HttpClientResponse } from '@microsoft/sp-http';

require('../assets/css/fabric.min.css');
require('../assets/css/style.css');
export interface IPeopleInformationStates {
  PeopleData: any;
  ClientContactData: any;
  ExternalContactData: any;
}

export default class PeopleInformation extends React.Component<IPeopleInformationProps, IPeopleInformationStates> {

  constructor(props: IPeopleInformationProps, state: IPeopleInformationStates) {
    super(props);
    this.state = {
      PeopleData: [],
      ClientContactData: [],
      ExternalContactData: []
    };
  }

  public componentDidMount = async () => {
    await this.getPeopleData();
    await this.getClientContactData();
    await this.getExternalContactData();

  }

  private getPeopleData = async () => {
    try {
      const PeopleData = await sp.web.lists.getByTitle(this.props.ExodigoContactTitle).items.select("Title,Phone,Email,Role").get();
      if (PeopleData.length > 0) {
        this.setState({ PeopleData: PeopleData });
      }
    }
    catch (error) {
      console.log(error);
    }
  }

  private getClientContactData = async () => {
    try {
      const ClientContactData = await sp.web.lists.getByTitle(this.props.ClientContactTitle).items.select("Title,Phone,Email,Role").get();
      if (ClientContactData.length > 0) {
        this.setState({ ClientContactData: ClientContactData });
      }
    }
    catch (error) {
      console.log(error);
    }
  }

  private getExternalContactData = async () => {
    try {
      const ExternalContactData = await sp.web.lists.getByTitle(this.props.ManagerContactTitle).items.select("Title,Phone,Email,Role").get();
      if (ExternalContactData.length > 0) {
        this.setState({ ExternalContactData: ExternalContactData });
      }
    }
    catch (error) {
      console.log(error);
    }
  }

  public render(): React.ReactElement<IPeopleInformationProps> {
    const {
      description,
      isDarkTheme,
      environmentMessage,
      hasTeamsContext,
      userDisplayName
    } = this.props;

    return (
    <div className='Contact-wrapper'>
        <div className='PepopleInformation'>
            <p className='PepopleInformation-Title' style={{ fontSize : this.props.ContactTitleFontSize ? this.props.ContactTitleFontSize + "px" : "20px", color : this.props.ContactTitleFontColor ? this.props.ContactTitleFontColor  : "", textAlign : this.props.ContactTitleFontAlignment ? this.props.ContactTitleFontAlignment  : "left"  }} >{this.props.ExodigoContactTitle? this.props.ExodigoContactTitle : "Exodigo Contacts" }</p>
            <div className='ms-Grid-row'>
            {
                this.state.PeopleData.length > 0 && (
                  this.state.PeopleData.map((item) => {
                    let imageURL = item.Image ? JSON.parse(item.Image).serverRelativeUrl : require('../assets/Images/userdefault.jpg');
                    return (
                      <div className="ms-Grid-col ms-sm12 ms-md12">
                      <div className='People-card'>  
                          {/* <img src={imageURL} /> */}
                          <div>
                            <h6 style={{ fontSize : this.props.ContactPersonNameFontSize ? this.props.ContactPersonNameFontSize + "px" : "18px", color : this.props.ContactPersonNameFontColor ? this.props.ContactPersonNameFontColor  : "" }}>{item.Title ? item.Title : ''}</h6>
                            <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }} >{item.Phone ? item.Phone : ''}</p>
                            <a href={'mailto:' + item.Email} style={{color:"inherit"}}>
                            <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }}>{item.Email ? item.Email : ''}</p>
                            </a>
                            <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }}>{item.Role ? item.Role : ''}</p>
                          </div>
                      </div>
                    </div>
                    );
                  })
                )
              }
            </div>
        </div>
        <div className='PepopleInformation'>
            <p className='PepopleInformation-Title' style={{ fontSize : this.props.ContactTitleFontSize ? this.props.ContactTitleFontSize + "px" : "20px", color : this.props.ContactTitleFontColor ? this.props.ContactTitleFontColor  : "", textAlign : this.props.ContactTitleFontAlignment ? this.props.ContactTitleFontAlignment  : "left"  }} >{this.props.ClientContactTitle? this.props.ClientContactTitle : "Client Contacts" }</p>
            <div className='ms-Grid-row'>
            {
                this.state.ClientContactData.length > 0 && (
                  this.state.ClientContactData.map((item) => {
                    let imageURL = item.Image ? JSON.parse(item.Image).serverRelativeUrl : require('../assets/Images/userdefault.jpg');
                    return (
                      <div className="ms-Grid-col ms-sm12 ms-md12">
                      <div className='People-card'>  
                          {/* <img src={imageURL} /> */}
                          <div>
                            <h6 style={{ fontSize : this.props.ContactPersonNameFontSize ? this.props.ContactPersonNameFontSize + "px" : "18px", color : this.props.ContactPersonNameFontColor ? this.props.ContactPersonNameFontColor  : "" }}>{item.Title ? item.Title : ''}</h6>
                            <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }} >{item.Phone ? item.Phone : ''}</p>
                            <a href={'mailto:' + item.Email} style={{color:"inherit"}}>
                            <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }}>{item.Email ? item.Email : ''}</p>
                            </a>
                            {/* <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }}>{item.Role ? item.Role : ''}</p> */}
                          </div>
                      </div>
                    </div>
                    );
                  })
                )
              }
            </div>
        </div>
        <div className='PepopleInformation'>
            <p className='PepopleInformation-Title' style={{ fontSize : this.props.ContactTitleFontSize ? this.props.ContactTitleFontSize + "px" : "20px", color : this.props.ContactTitleFontColor ? this.props.ContactTitleFontColor  : "", textAlign : this.props.ContactTitleFontAlignment ? this.props.ContactTitleFontAlignment  : "left"  }} >{this.props.ManagerContactTitle? this.props.ManagerContactTitle : "Line Manager Contacts" }</p>
            <div className='ms-Grid-row'>
            {
                this.state.ExternalContactData.length > 0 && (
                  this.state.ExternalContactData.map((item) => {
                    let imageURL = item.Image ? JSON.parse(item.Image).serverRelativeUrl : require('../assets/Images/userdefault.jpg');
                    return (
                      <div className="ms-Grid-col ms-sm12 ms-md12">
                      <div className='People-card'>  
                          {/* <img src={imageURL} /> */}
                          <div>
                            <h6 style={{ fontSize : this.props.ContactPersonNameFontSize ? this.props.ContactPersonNameFontSize + "px" : "18px", color : this.props.ContactPersonNameFontColor ? this.props.ContactPersonNameFontColor  : "" }}>{item.Title ? item.Title : ''}</h6>
                            <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }} >{item.Phone ? item.Phone : ''}</p>
                            <a href={'mailto:' + item.Email} style={{color:"inherit"}}>
                            <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }}>{item.Email ? item.Email : ''}</p>
                            </a>
                            {/* <p style={{ fontSize : this.props.ContactPersonDetailFontSize ? this.props.ContactPersonDetailFontSize + "px" : "14px", color : this.props.ContactPersonDetailFontColor ? this.props.ContactPersonDetailFontColor  : "" }}>{item.Role ? item.Role : ''}</p> */}
                          </div>
                      </div>
                    </div>
                    );
                  })
                )
              }
            </div>
        </div>
    </div>
    );
  }
}
