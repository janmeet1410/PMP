import * as React from 'react';
import { IContactCsProps } from './IContactCsProps';
export default class ContactCs extends React.Component<IContactCsProps, {}> {
    render(): React.ReactElement<IContactCsProps>;
}
//# sourceMappingURL=ContactCs.d.ts.map